package noppapeli;

public class Main {
    public static void main(String[] args) {
        kayttoliittyma liittyma = new kayttoliittyma();
        liittyma.kaynnista();
    }
}
